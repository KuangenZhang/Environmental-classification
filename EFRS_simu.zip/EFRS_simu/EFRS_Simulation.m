clear;
clc;
dataLen = 100;
vecUpStairs = cell(1,dataLen);
vecDownStairs = cell(1,dataLen);
vecGround = cell(1,dataLen);
vecUpRamp = cell(1,dataLen);
vecDownRamp = cell(1,dataLen);
imgPath='0-dataSet/';
randAmp = 0.01;
span = 0.005;
x0 = 0.2;
%%
tic
for t = 1:dataLen
    theta = getRandMat(1);
    cloudXYZ = generatePlane(theta,span,randAmp);
    vecGround{t} = cloudXYZ;
    binaryImg = setOccupancyMap(cloudXYZ(:,[1,3]),1);
    imwrite(binaryImg,[imgPath,num2str(1),'/','simuImg_',num2str(t),'.png']);
    
    tRad = deg2rad(t);
    w = 0.33 + 0.05*sin(tRad);
    h = 0.15 + 0.05*sin(tRad);
    cloudXYZ = generateStairs(w,h,x0,span,randAmp);
    vecUpStairs{t} = cloudXYZ;
    binaryImg = setOccupancyMap(cloudXYZ(:,[1,3]),1);
    imwrite(binaryImg,[imgPath,num2str(2),'/','simuImg_',num2str(t),'.png']);
    
    h = -0.15 + 0.05*sin(tRad);
    cloudXYZ = generateStairs(w,h,x0,span,randAmp);
    vecDownStairs{t} = cloudXYZ;
    binaryImg = setOccupancyMap(cloudXYZ(:,[1,3]),1);
    imwrite(binaryImg,[imgPath,num2str(3),'/','simuImg_',num2str(t),'.png']);
    
    theta = 15+5*sin(tRad);
    cloudXYZ = generatePlane(theta,span,randAmp);
    vecUpRamp{t} = cloudXYZ;
    binaryImg = setOccupancyMap(cloudXYZ(:,[1,3]),1);
    imwrite(binaryImg,[imgPath,num2str(4),'/','simuImg_',num2str(t),'.png']);
    
    theta = -15+5*sin(tRad);
    cloudXYZ = generatePlane(theta,span,randAmp);
    vecDownRamp{t} = cloudXYZ;
    binaryImg = setOccupancyMap(cloudXYZ(:,[1,3]),1);
    imwrite(binaryImg,[imgPath,num2str(5),'/','simuImg_',num2str(t),'.png']);       
end
toc
%% 
fileName = [imgPath,'pointsClouds.mat'];
save(fileName,'vecGround','vecUpStairs','vecDownStairs','vecUpRamp','vecDownRamp','-v7.3');
%%
fileName = [imgPath,'pointsClouds.mat'];
load(fileName);
%%
figure(1);
pcshow(vecGround{100}, 'MarkerSize',20);
axis off;
figure(2);
pcshow(vecUpStairs{100}, 'MarkerSize',20);
axis off;
figure(3);
pcshow(vecDownStairs{100}, 'MarkerSize',20);
axis off;
figure(4);
pcshow(vecUpRamp{100}, 'MarkerSize',20);
axis square;
axis off;
figure(5);
pcshow(vecDownRamp{100}, 'MarkerSize',20);
axis square;
axis off;
view([20 0]);
%%
tRad = deg2rad(1:dataLen);
thetaUpRamp = 15 * ones(size(tRad))+5*sin(tRad);
thetaDownRamp = -15 * ones(size(tRad))+5*sin(tRad);
wStairs = 0.33 * ones(size(tRad)) + 0.05*sin(tRad);
hStairs = 0.15 * ones(size(tRad)) + 0.05*sin(tRad);
thetaUpRampPred = zeros(1,dataLen);
thetaDownRampPred = zeros(1,dataLen);
wStairsPred = zeros(1,dataLen);
hStairsPred = zeros(1,dataLen);
hDownStairsPred = zeros(1,dataLen);
%%
parfor i = 1:dataLen
    cloudXYZ = vecUpRamp{i};
    [thetaUpRampPred(i),~] = fitLineForSimuPoints(cloudXYZ(:,1),cloudXYZ(:,3),5);
    cloudXYZ = vecDownRamp{i};
    [thetaDownRampPred(i),~] = fitLineForSimuPoints(cloudXYZ(:,1),cloudXYZ(:,3),5);
end
%%
tic
parfor i = 1:dataLen
    cloudXYZ = vecUpStairs{i};
    [wStairsPred(i),hStairsPred(i)] = ransacFitSimuStair(cloudXYZ(:,[1,3]),5,0.05);
end
toc
%%
figure;
plot(thetaUpRamp','k','LineWidth',1);
hold on;
plot(thetaUpRampPred,'r--','LineWidth',3);
legend('Actual value','Predicted value');
xlabel('Image Index');
ylabel(['Slope Angle of Up Ramp/',char(176)]);
% title('Features Prediction Results');
figure;
plot(thetaDownRamp','k','LineWidth',1);
hold on;
plot(thetaDownRampPred','r--','LineWidth',3);
legend('Actual value','Predicted value');
xlabel('Image Index');
ylabel(['Slope Angle of Down Ramp/',char(176)]);
% title('Features Prediction Results');
figure;
plot(wStairs','k','LineWidth',1);
hold on;
plot(wStairsPred','r--','LineWidth',3);
legend('Actual value','Predicted value');
xlabel('Image Index');
ylabel('Width of Stair/m');
% title('Features Prediction Results');
figure;
plot(hStairs','k','LineWidth',1);
hold on;
plot(hStairsPred','r--','LineWidth',3);
legend('Actual value','Predicted value');
xlabel('Image Index');
ylabel('Height of Stair/m');
% title('Features Prediction Results');

%%
errorThetaUp = (thetaUpRampPred - thetaUpRamp)./thetaUpRamp;
errorThetaDown = (thetaDownRampPred - thetaDownRamp)./thetaDownRamp;
errorW = (wStairsPred - wStairs)./wStairs;
errorH = (hStairsPred - hStairs)./hStairs;
mean(errorThetaUp)
mean(errorThetaDown)
mean(errorW)
mean(errorH)
figure;
plot([errorThetaUp',errorThetaDown'],'LineWidth',1);
legend('Up Ramp','Down Ramp');
xlabel('Image Index');
ylabel('Percentage Error of Slope Angles');
ylim([-0.05,0.05]);
figure;
plot([errorW',errorH'],'LineWidth',1);
legend('Width','Height');
xlabel('Image Index');
ylabel('Percentage Error of Stair Features');
ylim([-0.05,0.05]);
%%
function cloudXYZ = generatePlane(theta,span,randAmp)
y=0:span:0.1;
x=0:span:1;
[X,Y]=meshgrid(x,y);
Z =tan(deg2rad(theta))* X + randAmp*getRandMat(X); 
cloudXYZ=[X(:) Y(:) Z(:)];
end

function cloudXYZ = generateStairs(w,h,x0,span,randAmp)
cloudXYZ = [];
y=0:span:0.1;
for i = 1:4
    if i == 1
        x= 0:span:x0;
    else if(i == 4)
            x= x0+(i-2)*w:span:1;
        else
            x= x0+(i-2)*w:span:x0+(i-1)*w;
        end
    end
    [X,Y]=meshgrid(x,y);
    Z =(i-1)*h + randAmp*getRandMat(X);   %add noise
    cloudXYZ=[cloudXYZ;[X(:) Y(:) Z(:)]];
end
for i = 1:3
    if h>0
        z=(i-1)*h+randAmp:span:i*h-randAmp;
    else
        z=i*h+randAmp:span:(i-1)*h-randAmp;
    end
    [Y,Z]=meshgrid(y,z);
    if h>0
        X=x0+randAmp+(i-1)*w+randAmp*getRandMat(Y);
    else
        
        X=x0-randAmp+(i-1)*w+randAmp*getRandMat(Y);
    end
    cloudXYZ=[cloudXYZ;[X(:) Y(:) Z(:)]];
end
end

function randMat = getRandMat(X)
    randMat = imnoise(zeros(size(X)),'gaussian',0,1e-4);
    randMat = -ones(size(X))+2*rand(size(X));
end


function binaryImg = setOccupancyMap(points,maxValue)
    map = robotics.BinaryOccupancyGrid(1,1,100);
    pointsToUnit = points;
    pointsToUnit(:,1) = pointsToUnit(:,1) - min(pointsToUnit(:,1)) + 0.01;
    pointsToUnit(pointsToUnit(:,1)>(maxValue - 0.01),:) = [];
    pointsToUnit(:,2) = pointsToUnit(:,2) - min(pointsToUnit(:,2)) + 0.01;
    pointsToUnit(pointsToUnit(:,2)>(maxValue - 0.01),:) = [];
    if ~isempty(pointsToUnit)
        setOccupancy(map,pointsToUnit,1);
    end
    binaryImg = occupancyMatrix(map);
end

function [slopeAngle,points] = fitLineForSimuPoints(x,y,winLen)
    matXY = [x,y];
    [~,idx] = sort(x); % sort just the first column
    points = matXY(idx,:);   % sort the whole matrix using the sort indices
    x = medfilt1(points(:,1),winLen);
    y = medfilt1(points(:,2),winLen);
    points = [x,y];
    P = polyfit(x,y,1);
    slope = P(1);
    slopeAngle = rad2deg(atan(slope));
end


function [stepWidth,stepHeight] = ransacFitSimuStair(points2d,sampleSize,maxDistance)
    [~,index] = sort(points2d(:,1));
    points2dFilt = points2d(index,:);
    [modelInliers1,inlierIdx,inliersPts1] = ...
        ransacFitline(points2dFilt,sampleSize,maxDistance);
    points2dFilt(inlierIdx,:) = [];
    [modelInliers2,~,inliersPts2] = ...
        ransacFitline(points2dFilt,sampleSize,maxDistance);
    yMed1 = mean(inliersPts1(:,2));
    yMed2 = mean(inliersPts2(:,2));
    stepHeight = abs(yMed2 - yMed1);
    stepWidth = abs(inliersPts2(1,1)-inliersPts1(1,1));
end


function [modelInliers,inlierIdx,inlierPts] = ransacFitline(points2d,...
                sampleSize,maxDistance,isFitModel)
    if nargin < 4
        isFitModel = true;
    end
    % sampleSize = 2; % number of points to sample per trial
    % maxDistance = 0.02; % max allowable distance for inliers
    fitLineFcn = @(points) polyfit(points(:,1),points(:,2),0); % fit function using polyfit
    distFcn = ...   % distance evaluation function
        @(model, points) abs((points(:, 2) - polyval(model, points(:,1))));
    try
        [~, inlierIdx] = ransac(points2d,fitLineFcn,distFcn, ...
            sampleSize,maxDistance,'MaxNumTrials',10,'Confidence',60);
        modelInliers = [];
        if isFitModel
            modelInliers = polyfit(points2d(inlierIdx,1),points2d(inlierIdx,2),1);
        end
        inlierPts = points2d(inlierIdx,:);
    catch
        inlierIdx = [];
        modelInliers = [];
    end
end